﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class guia
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtCounters = New System.Windows.Forms.TextBox()
        Me.txtBuild = New System.Windows.Forms.TextBox()
        Me.txtRunas = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.cmbcampeao = New System.Windows.Forms.ComboBox()
        Me.lblcampeão = New System.Windows.Forms.Label()
        Me.btnexibir = New System.Windows.Forms.Button()
        Me.btncancelar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtCounters
        '
        Me.txtCounters.Location = New System.Drawing.Point(121, 268)
        Me.txtCounters.Multiline = True
        Me.txtCounters.Name = "txtCounters"
        Me.txtCounters.Size = New System.Drawing.Size(270, 26)
        Me.txtCounters.TabIndex = 23
        '
        'txtBuild
        '
        Me.txtBuild.Location = New System.Drawing.Point(121, 192)
        Me.txtBuild.Multiline = True
        Me.txtBuild.Name = "txtBuild"
        Me.txtBuild.Size = New System.Drawing.Size(270, 57)
        Me.txtBuild.TabIndex = 22
        '
        'txtRunas
        '
        Me.txtRunas.Location = New System.Drawing.Point(118, 109)
        Me.txtRunas.Multiline = True
        Me.txtRunas.Name = "txtRunas"
        Me.txtRunas.Size = New System.Drawing.Size(273, 63)
        Me.txtRunas.TabIndex = 21
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(118, 252)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(49, 13)
        Me.label3.TabIndex = 20
        Me.label3.Text = "couters"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(118, 175)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(34, 13)
        Me.label2.TabIndex = 19
        Me.label2.Text = "build"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(115, 93)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(43, 13)
        Me.label1.TabIndex = 18
        Me.label1.Text = "Runas"
        '
        'cmbcampeao
        '
        Me.cmbcampeao.FormattingEnabled = True
        Me.cmbcampeao.Location = New System.Drawing.Point(118, 58)
        Me.cmbcampeao.Name = "cmbcampeao"
        Me.cmbcampeao.Size = New System.Drawing.Size(121, 21)
        Me.cmbcampeao.TabIndex = 16
        '
        'lblcampeão
        '
        Me.lblcampeão.AutoSize = True
        Me.lblcampeão.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcampeão.Location = New System.Drawing.Point(118, 39)
        Me.lblcampeão.Name = "lblcampeão"
        Me.lblcampeão.Size = New System.Drawing.Size(58, 13)
        Me.lblcampeão.TabIndex = 24
        Me.lblcampeão.Text = "campeão"
        '
        'btnexibir
        '
        Me.btnexibir.BackColor = System.Drawing.Color.Yellow
        Me.btnexibir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexibir.Location = New System.Drawing.Point(118, 310)
        Me.btnexibir.Name = "btnexibir"
        Me.btnexibir.Size = New System.Drawing.Size(75, 23)
        Me.btnexibir.TabIndex = 25
        Me.btnexibir.Text = "exibir"
        Me.btnexibir.UseVisualStyleBackColor = False
        '
        'btncancelar
        '
        Me.btncancelar.BackColor = System.Drawing.Color.Red
        Me.btncancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelar.ForeColor = System.Drawing.Color.White
        Me.btncancelar.Location = New System.Drawing.Point(316, 310)
        Me.btncancelar.Name = "btncancelar"
        Me.btncancelar.Size = New System.Drawing.Size(75, 23)
        Me.btncancelar.TabIndex = 26
        Me.btncancelar.Text = "cancelar"
        Me.btncancelar.UseVisualStyleBackColor = False
        '
        'guia
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 358)
        Me.Controls.Add(Me.btncancelar)
        Me.Controls.Add(Me.btnexibir)
        Me.Controls.Add(Me.lblcampeão)
        Me.Controls.Add(Me.txtCounters)
        Me.Controls.Add(Me.txtBuild)
        Me.Controls.Add(Me.txtRunas)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.cmbcampeao)
        Me.Name = "guia"
        Me.Text = "guia"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtCounters As TextBox
    Private WithEvents txtBuild As TextBox
    Private WithEvents txtRunas As TextBox
    Private WithEvents label3 As Label
    Private WithEvents label2 As Label
    Private WithEvents label1 As Label
    Private WithEvents cmbcampeao As ComboBox
    Friend WithEvents lblcampeão As Label
    Friend WithEvents btnexibir As Button
    Friend WithEvents btncancelar As Button
End Class
