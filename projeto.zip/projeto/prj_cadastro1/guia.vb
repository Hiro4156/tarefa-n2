﻿Imports ADODB

Public Class guia

    Private Sub guia_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        carregarCampeoes()
    End Sub
    Sub carregarCampeoes()
        Try
            rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT nome FROM tb_campeao ORDER BY nome", db)

            cmbcampeao.Items.Clear()
            Do While Not rs.EOF
                cmbcampeao.Items.Add(rs.Fields("nome").Value.ToString())
                rs.MoveNext()
            Loop
        Catch ex As Exception
            MsgBox("Erro ao carregar campeões: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        telas.Show()
        Me.Hide()
    End Sub

    Private Sub btnexibir_Click(sender As Object, e As EventArgs) Handles btnexibir.Click
        If cmbcampeao.SelectedIndex = -1 Then
            MsgBox("Selecione um campeão.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If

        Try
            rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT * FROM tb_campeao WHERE nome = '" & cmbcampeao.Text & "'", db)

            If Not rs.EOF Then
                txtRunas.Text = rs.Fields("runas").Value.ToString()
                txtBuild.Text = rs.Fields("build").Value.ToString()
                txtCounters.Text = rs.Fields("counters").Value.ToString()

            Else
                MsgBox("Campeão não encontrado.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            End If
        Catch ex As Exception
            MsgBox("Erro ao exibir informações: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

End Class