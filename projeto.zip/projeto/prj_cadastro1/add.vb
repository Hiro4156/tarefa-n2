﻿Imports ADODB

Public Class add

    Private Sub adicionarcamp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        carregarUsuarios()
        carregarCampeoes()
    End Sub
    Sub carregarUsuarios()
        Try
            rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT usuario FROM tb_usuario", db)
            cmbusuario.Items.Clear()
            While Not rs.EOF
                cmbusuario.Items.Add(rs.Fields("usuario").Value)
                rs.MoveNext()
            End While
        Catch ex As Exception
            MsgBox("Erro ao carregar usuários: " & ex.Message)
        End Try
    End Sub
    Sub carregarCampeoes()
        Try
            rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT nome FROM tb_campeao", db)
            cmbCampeao.Items.Clear()
            While Not rs.EOF
                cmbCampeao.Items.Add(rs.Fields("nome").Value)
                rs.MoveNext()
            End While
        Catch ex As Exception
            MsgBox("Erro ao carregar campeões: " & ex.Message)
        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If cmbusuario.Text = "" Then
            MsgBox("Selecione um usuário para deletar.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If

        If MsgBox("Deseja realmente excluir o usuário '" & cmbusuario.Text & "'?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmação") = MsgBoxResult.Yes Then
            Try
                ' Busca o id do usuário pelo nome
                Dim rs = CreateObject("ADODB.Recordset")
                rs.Open("SELECT id FROM tb_usuario WHERE usuario='" & cmbusuario.Text.Replace("'", "''") & "'", db)

                If rs.EOF Then
                    MsgBox("Usuário não encontrado.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                    Exit Sub
                End If

                Dim idUsuario As Integer = rs.Fields("id").Value

                ' Deleta as partidas relacionadas
                db.Execute("DELETE FROM tb_partidas WHERE id_usuario = " & idUsuario)

                ' Deleta o usuário
                db.Execute("DELETE FROM tb_usuario WHERE id = " & idUsuario)

                MsgBox("Usuário deletado com sucesso.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                carregarUsuarios()

            Catch ex As Exception
                MsgBox("Erro ao deletar usuário: " & ex.Message, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            End Try
        End If

    End Sub

    Private Sub deletar_Click(sender As Object, e As EventArgs) Handles deletar.Click
        If cmbCampeao.Text = "" Then
            MsgBox("Selecione um campeão para deletar.", MsgBoxStyle.Exclamation, "Atenção")
            Exit Sub
        End If

        If MsgBox("Deseja realmente excluir o campeão '" & cmbCampeao.Text & "'?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmação") = MsgBoxResult.Yes Then
            Try
                db.Execute("DELETE FROM tb_campeao WHERE nome='" & cmbCampeao.Text & "'")
                MsgBox("Campeão deletado com sucesso.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                carregarCampeoes()
            Catch ex As Exception
                MsgBox("Erro ao deletar campeão: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        telas.Show()
        Me.Hide()
    End Sub
End Class