﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class cadastropart
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.label2 = New System.Windows.Forms.Label()
        Me.txtitens = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.nudAssistencias = New System.Windows.Forms.NumericUpDown()
        Me.nudMortes = New System.Windows.Forms.NumericUpDown()
        Me.nudKills = New System.Windows.Forms.NumericUpDown()
        Me.label3 = New System.Windows.Forms.Label()
        Me.re = New System.Windows.Forms.Label()
        Me.campeão = New System.Windows.Forms.Label()
        Me.button1 = New System.Windows.Forms.Button()
        Me.txtcampeao = New System.Windows.Forms.TextBox()
        Me.txtoponente = New System.Windows.Forms.TextBox()
        Me.txtresultado = New System.Windows.Forms.TextBox()
        CType(Me.nudAssistencias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudMortes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKills, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(170, 169)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(59, 13)
        Me.label2.TabIndex = 47
        Me.label2.Text = "resultado"
        '
        'txtitens
        '
        Me.txtitens.Location = New System.Drawing.Point(172, 292)
        Me.txtitens.Multiline = True
        Me.txtitens.Name = "txtitens"
        Me.txtitens.Size = New System.Drawing.Size(338, 35)
        Me.txtitens.TabIndex = 46
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(172, 275)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(34, 13)
        Me.label1.TabIndex = 45
        Me.label1.Text = "itens"
        '
        'button2
        '
        Me.button2.BackColor = System.Drawing.Color.Red
        Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.ForeColor = System.Drawing.Color.White
        Me.button2.Location = New System.Drawing.Point(435, 333)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 44
        Me.button2.Text = "cancelar"
        Me.button2.UseVisualStyleBackColor = False
        '
        'nudAssistencias
        '
        Me.nudAssistencias.Location = New System.Drawing.Point(254, 235)
        Me.nudAssistencias.Name = "nudAssistencias"
        Me.nudAssistencias.Size = New System.Drawing.Size(39, 20)
        Me.nudAssistencias.TabIndex = 43
        '
        'nudMortes
        '
        Me.nudMortes.Location = New System.Drawing.Point(213, 235)
        Me.nudMortes.Name = "nudMortes"
        Me.nudMortes.Size = New System.Drawing.Size(34, 20)
        Me.nudMortes.TabIndex = 42
        '
        'nudKills
        '
        Me.nudKills.Location = New System.Drawing.Point(171, 235)
        Me.nudKills.Name = "nudKills"
        Me.nudKills.Size = New System.Drawing.Size(34, 20)
        Me.nudKills.TabIndex = 41
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(169, 208)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(147, 13)
        Me.label3.TabIndex = 37
        Me.label3.Text = "kills/mortes/assistências"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        're
        '
        Me.re.AutoSize = True
        Me.re.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.re.Location = New System.Drawing.Point(169, 125)
        Me.re.Name = "re"
        Me.re.Size = New System.Drawing.Size(60, 13)
        Me.re.TabIndex = 36
        Me.re.Text = "oponente"
        '
        'campeão
        '
        Me.campeão.AutoSize = True
        Me.campeão.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.campeão.Location = New System.Drawing.Point(169, 67)
        Me.campeão.Name = "campeão"
        Me.campeão.Size = New System.Drawing.Size(58, 13)
        Me.campeão.TabIndex = 35
        Me.campeão.Text = "campeão"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.Color.White
        Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button1.Location = New System.Drawing.Point(172, 333)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 34
        Me.button1.Text = "salvar"
        Me.button1.UseVisualStyleBackColor = False
        '
        'txtcampeao
        '
        Me.txtcampeao.Location = New System.Drawing.Point(172, 82)
        Me.txtcampeao.Name = "txtcampeao"
        Me.txtcampeao.Size = New System.Drawing.Size(100, 20)
        Me.txtcampeao.TabIndex = 48
        '
        'txtoponente
        '
        Me.txtoponente.Location = New System.Drawing.Point(172, 142)
        Me.txtoponente.Name = "txtoponente"
        Me.txtoponente.Size = New System.Drawing.Size(100, 20)
        Me.txtoponente.TabIndex = 49
        '
        'txtresultado
        '
        Me.txtresultado.Location = New System.Drawing.Point(172, 186)
        Me.txtresultado.Name = "txtresultado"
        Me.txtresultado.Size = New System.Drawing.Size(100, 20)
        Me.txtresultado.TabIndex = 50
        '
        'cadastropart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(538, 450)
        Me.Controls.Add(Me.txtresultado)
        Me.Controls.Add(Me.txtoponente)
        Me.Controls.Add(Me.txtcampeao)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtitens)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.nudAssistencias)
        Me.Controls.Add(Me.nudMortes)
        Me.Controls.Add(Me.nudKills)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.re)
        Me.Controls.Add(Me.campeão)
        Me.Controls.Add(Me.button1)
        Me.Name = "cadastropart"
        Me.Text = "cadastropart"
        CType(Me.nudAssistencias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudMortes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKills, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents label2 As Label
    Private WithEvents txtitens As TextBox
    Private WithEvents label1 As Label
    Private WithEvents button2 As Button
    Private WithEvents nudAssistencias As NumericUpDown
    Private WithEvents nudMortes As NumericUpDown
    Private WithEvents nudKills As NumericUpDown
    Private WithEvents label3 As Label
    Private WithEvents re As Label
    Private WithEvents campeão As Label
    Private WithEvents button1 As Button
    Friend WithEvents txtcampeao As TextBox
    Friend WithEvents txtoponente As TextBox
    Friend WithEvents txtresultado As TextBox
End Class
