﻿Imports ADODB

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT * FROM tb_usuario WHERE usuario='" & txtusuario.Text & "' AND senha='" & txtsenha.Text & "'", db)

            If Not rs.EOF Then

                usuarioLogadoId = rs.Fields("id").Value


                telas.isAdmin = (rs.Fields("tipo").Value.ToString().ToLower() = "admin")

                MsgBox("Login realizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                telas.Show()
                Me.Hide()
            Else
                MsgBox("Usuário ou senha incorretos.", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            End If

        Catch ex As Exception
            MsgBox("Erro ao consultar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        Finally
            If rs.State = 1 Then rs.Close()
        End Try
    End Sub
    Private Sub llbcadastrar_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbcadastrar.LinkClicked
        cadastro.Show()
        Me.Hide()
    End Sub
End Class
