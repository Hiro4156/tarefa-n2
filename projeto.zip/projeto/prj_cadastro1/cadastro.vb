﻿Public Class cadastro
    Private Sub button1_Click(sender As Object, e As EventArgs) Handles btncadastrar.Click
        If txtusuario.Text = "" Or txtsenha.Text = "" Then
            MsgBox("Preencha todos os campos.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Exit Sub
        End If

        Try
            Dim tipoUsuario As String = If(CheckBox1.Checked, "admin", "comum")
            db.Execute("INSERT INTO tb_usuario (usuario, senha, tipo) VALUES ('" & txtusuario.Text & "', '" & txtsenha.Text & "', '" & tipoUsuario & "')")
            MsgBox("Cadastro realizado com sucesso!", MsgBoxStyle.Information, "TopStatic")
            Form1.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox("Erro ao cadastrar: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        Form1.Show()
        Me.Close()
    End Sub

End Class