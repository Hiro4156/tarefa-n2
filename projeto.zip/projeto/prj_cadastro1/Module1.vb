﻿Module Module1
    Public usuarioLogadoId As Integer
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset

    Sub conecta_banco()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Driver={MySQL ODBC 3.51 Driver};Server=127.0.0.1;Port=3307;Database=topstatic;User=root;Password=usbw;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao conectar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
End Module
