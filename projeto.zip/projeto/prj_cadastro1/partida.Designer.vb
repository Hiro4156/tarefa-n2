﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class partida
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.button1 = New System.Windows.Forms.Button()
        Me.dgvPartidas = New System.Windows.Forms.DataGridView()
        Me.data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.campeão = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.oponente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.resultado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.itens = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btncancelar = New System.Windows.Forms.Button()
        CType(Me.dgvPartidas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(85, 305)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(148, 23)
        Me.button1.TabIndex = 5
        Me.button1.Text = "adicionar partida"
        Me.button1.UseVisualStyleBackColor = True
        '
        'dgvPartidas
        '
        Me.dgvPartidas.BackgroundColor = System.Drawing.Color.White
        Me.dgvPartidas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPartidas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.data, Me.campeão, Me.oponente, Me.resultado, Me.itens})
        Me.dgvPartidas.GridColor = System.Drawing.Color.Black
        Me.dgvPartidas.Location = New System.Drawing.Point(94, 65)
        Me.dgvPartidas.Name = "dgvPartidas"
        Me.dgvPartidas.Size = New System.Drawing.Size(545, 213)
        Me.dgvPartidas.TabIndex = 4
        '
        'data
        '
        Me.data.HeaderText = "data"
        Me.data.Name = "data"
        '
        'campeão
        '
        Me.campeão.HeaderText = "campeão"
        Me.campeão.Name = "campeão"
        '
        'oponente
        '
        Me.oponente.HeaderText = "oponente"
        Me.oponente.Name = "oponente"
        '
        'resultado
        '
        Me.resultado.HeaderText = "resultado"
        Me.resultado.Name = "resultado"
        '
        'itens
        '
        Me.itens.HeaderText = "itens"
        Me.itens.Name = "itens"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(173, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(334, 37)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Histórico de Partidas"
        '
        'btncancelar
        '
        Me.btncancelar.BackColor = System.Drawing.Color.Red
        Me.btncancelar.ForeColor = System.Drawing.Color.White
        Me.btncancelar.Location = New System.Drawing.Point(537, 305)
        Me.btncancelar.Name = "btncancelar"
        Me.btncancelar.Size = New System.Drawing.Size(93, 23)
        Me.btncancelar.TabIndex = 7
        Me.btncancelar.Text = "cancelar"
        Me.btncancelar.UseVisualStyleBackColor = False
        '
        'partida
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(719, 354)
        Me.Controls.Add(Me.btncancelar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.dgvPartidas)
        Me.Name = "partida"
        Me.Text = "partida"
        CType(Me.dgvPartidas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents button1 As Button
    Private WithEvents dgvPartidas As DataGridView
    Private WithEvents data As DataGridViewTextBoxColumn
    Private WithEvents campeão As DataGridViewTextBoxColumn
    Private WithEvents oponente As DataGridViewTextBoxColumn
    Private WithEvents resultado As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents btncancelar As Button
    Friend WithEvents itens As DataGridViewTextBoxColumn
End Class
