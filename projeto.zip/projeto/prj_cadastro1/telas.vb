﻿Imports ADODB

Public Class telas


    Public Shared isAdmin As Boolean = False
    Private Sub telas_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        btnadmin.Visible = isAdmin
    End Sub

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        guia.Show()
        Me.Hide()
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        partida.Show()
        Me.Hide()
    End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        End
    End Sub

    Private Sub btnadmin_Click(sender As Object, e As EventArgs) Handles btnadmin.Click
        add.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        cadastropart.Show()
        Me.Hide()
    End Sub
End Class