﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class add
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblusuario = New System.Windows.Forms.Label()
        Me.cmbusuario = New System.Windows.Forms.ComboBox()
        Me.cmbCampeao = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblcampeao = New System.Windows.Forms.Label()
        Me.deletar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblusuario
        '
        Me.lblusuario.AutoSize = True
        Me.lblusuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusuario.Location = New System.Drawing.Point(102, 52)
        Me.lblusuario.Name = "lblusuario"
        Me.lblusuario.Size = New System.Drawing.Size(48, 13)
        Me.lblusuario.TabIndex = 0
        Me.lblusuario.Text = "usuário"
        '
        'cmbusuario
        '
        Me.cmbusuario.FormattingEnabled = True
        Me.cmbusuario.Location = New System.Drawing.Point(178, 49)
        Me.cmbusuario.Name = "cmbusuario"
        Me.cmbusuario.Size = New System.Drawing.Size(121, 21)
        Me.cmbusuario.TabIndex = 1
        '
        'cmbCampeao
        '
        Me.cmbCampeao.FormattingEnabled = True
        Me.cmbCampeao.Location = New System.Drawing.Point(178, 142)
        Me.cmbCampeao.Name = "cmbCampeao"
        Me.cmbCampeao.Size = New System.Drawing.Size(121, 21)
        Me.cmbCampeao.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Red
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(224, 89)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "deletar"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'lblcampeao
        '
        Me.lblcampeao.AutoSize = True
        Me.lblcampeao.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcampeao.Location = New System.Drawing.Point(102, 149)
        Me.lblcampeao.Name = "lblcampeao"
        Me.lblcampeao.Size = New System.Drawing.Size(58, 13)
        Me.lblcampeao.TabIndex = 4
        Me.lblcampeao.Text = "campeão"
        '
        'deletar
        '
        Me.deletar.BackColor = System.Drawing.Color.Red
        Me.deletar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deletar.ForeColor = System.Drawing.Color.White
        Me.deletar.Location = New System.Drawing.Point(224, 187)
        Me.deletar.Name = "deletar"
        Me.deletar.Size = New System.Drawing.Size(75, 23)
        Me.deletar.TabIndex = 5
        Me.deletar.Text = "deletar"
        Me.deletar.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(178, 227)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "voltar"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 262)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.deletar)
        Me.Controls.Add(Me.lblcampeao)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.cmbCampeao)
        Me.Controls.Add(Me.cmbusuario)
        Me.Controls.Add(Me.lblusuario)
        Me.Name = "add"
        Me.Text = "adicionarcamp"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblusuario As Label
    Friend WithEvents cmbusuario As ComboBox
    Friend WithEvents cmbCampeao As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents lblcampeao As Label
    Friend WithEvents deletar As Button
    Friend WithEvents Button2 As Button
End Class
