﻿Imports ADODB

Public Class cadastropart

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        Try
            Dim sql As String = "INSERT INTO tb_partidas (id_usuario, campeao, oponente, resultado, kills, mortes, assistencias, itens) " &
                        "VALUES (" & usuarioLogadoId & ", '" & txtcampeao.Text & "', '" & txtoponente.Text & "', '" & txtresultado.Text & "', " &
                        nudKills.Value & ", " & nudMortes.Value & ", " & nudAssistencias.Value & ", '" & txtitens.Text & "')"

            db.Execute(sql)

            MsgBox("Partida registrada com sucesso.", MsgBoxStyle.Information, "TopStatic")


            Dim frmPartida As partida = Application.OpenForms.OfType(Of partida)().FirstOrDefault()
            If frmPartida IsNot Nothing Then
                frmPartida.AtualizarGrid()
                frmPartida.Show()
                frmPartida.BringToFront()
            End If
            partida.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox("Erro ao registrar partida: " & ex.Message)
        End Try
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        telas.Show()
        Me.Hide()
    End Sub
End Class