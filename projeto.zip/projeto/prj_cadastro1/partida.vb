﻿Imports ADODB

Public Class partida
    Public Sub AtualizarGrid()
        carregarPartidas()
    End Sub

    Private Sub partidas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        carregarPartidas()
    End Sub
    Private Sub carregarPartidas()
        Try
            Dim rs = CreateObject("ADODB.Recordset")
            rs.Open("SELECT data_registro, campeao, oponente, resultado, itens FROM tb_partidas WHERE id_usuario = " & usuarioLogadoId & " ORDER BY data_registro DESC", db)

            ' Se colunas não foram criadas, cria elas
            If dgvPartidas.Columns.Count = 0 Then
                With dgvPartidas.Columns
                    .Add("colData", "Data")
                    .Add("colCampeao", "Campeão")
                    .Add("colOponente", "Oponente")
                    .Add("colResultado", "Resultado")
                    .Add("colItens", "Itens")
                End With
            Else
                dgvPartidas.Rows.Clear()
            End If

            ' Adiciona as linhas no grid
            Do While Not rs.EOF
                dgvPartidas.Rows.Add(
                rs.Fields("data_registro").Value,
                rs.Fields("campeao").Value,
                rs.Fields("oponente").Value,
                rs.Fields("resultado").Value,
                rs.Fields("itens").Value
            )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar partidas: " & ex.Message)
        End Try
    End Sub

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        cadastropart.Show()
        Me.Hide()
    End Sub

    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        telas.Show()
        Me.Hide()
    End Sub


End Class